# XXX: Typing support
from typing import List, Optional, Dict, Any
from pathlib import Path

# XXX: Standard library imports
import html
import zipfile
from os import path
import os
import hashlib
import subprocess
import json
import urllib.parse
import re

import malbook

# XXX: Third-party imports that need to be installed first
malbook.ensure_package('beautifulsoup4')
import bs4
malbook.ensure_package('pefile')
import pefile
malbook.ensure_package('yara-python')
import yara
malbook.ensure_package('requests')
import requests
malbook.ensure_package('peid')
import peid


class _Cache:

    _sample: str
    _cache: Dict[str, Dict[str, Any]]
    _cache_file: Path


    def __init__(self, cache_file: Path):
        try:
            with open(cache_file, 'rt') as f:
                self._cache = json.load(f)
        except:
            self._cache = {}

        self._cache_file = cache_file

        # Init common cache
        if 'common' not in self._cache:
            self._cache['common'] = {}

    def save(self):
        with open(self._cache_file, 'wt') as f:
            json.dump(self._cache, f)

    def set_current_sample(self, sample: str):
        self._sample = sample
        if sample not in self._cache:
            self._cache[sample] = {}

    def get(self, key: str):
        if key in self._cache[self._sample]:
            return self._cache[self._sample][key]
        return None

    def set(self, key: str, value: Any):
        self._cache[self._sample][key] = value

    def get_common(self, key: str):
        if key in self._cache['common']:
            return self._cache['common'][key]
        return None

    def set_common(self, key: str, value: Any):
        self._cache['common'][key] = value


_CWD = os.getcwd()


class Config:

    output_path: Path = path.join(_CWD, 'output')

    unzip: bool = True
    unzip_password: Optional[bytes] = b'infected'

    strings: bool = True
    strings_floss: Path = path.join(_CWD, 'bin', 'floss')
    strings_min_length: int = 8
    strings_regex_rules: Dict[str, re.Pattern] = {
        'http': re.compile(r'http.*'),
        'ipv4': re.compile(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}'),
    }

    yara: bool = True
    yara_rules: Path = path.join(_CWD, 'yara')
    yara_ignore: List[str] = []

    # Run PEID on sample to detect PE packer or compiler
    peid: bool = True

    # Scan PE imports
    imports: bool = True

    # Use a cache file to store results to make
    # consequent scans faster
    cache: bool = True


def scan(sample: Path, config: Config) -> None:
    if config.cache:
        cache_path = path.join(config.output_path, 'cache.json')
        cache = _Cache(cache_path)
    else:
        # XXX: Create discardable cache not backed by a file
        cache = _Cache('')

    if not path.exists(config.output_path):
        os.mkdir(config.output_path)

    if config.unzip:
        unzipped = _unzip(sample, config)
        for s in os.listdir(unzipped):
            sample_path = path.join(unzipped, s)
            _scan(sample_path, config, cache)
    else:
        _scan(sample, config, cache)

    if config.cache:
        cache.save()


def _scan(sample, config, cache):
    name = path.basename(sample)
    _head(name)

    with open(sample, 'rb') as f:
        data = f.read()

    # XXX: Loading file as a PE and computing its hashes
    # are the only mandatory scan steps.
    pe = _pe(data)
    _checksums(data, pe, config, cache)

    if config.strings:
        _strings(sample, config, cache)

    if config.yara:
        _yara(data, config, cache)

    if config.peid:
        _peid(sample, config, cache)

    if config.imports:
        _imports(pe, config, cache)


def _pe(data):
    try:
        pe = pefile.PE(data=data)
        pe.parse_data_directories()
        return pe
    except pefile.PEFormatError:
        raise malbook.Error('Sample is not a portable executable')


def _unzip(zip_path, config):
    with open(zip_path, 'rb') as f:
        data = f.read()

    sha256 = _csum(hashlib.sha256, data)
    zip_out = path.join(config.output_path, sha256)

    if path.exists(zip_out):
        # XXX: Got extracted previously
        return zip_out

    os.mkdir(zip_out)
    with zipfile.ZipFile(zip_path, 'r') as z:
        z.extractall(zip_out, pwd=config.unzip_password)

    return zip_out


def _imports(pe, config, cache):
    imports = cache.get('imports')
    if imports is None:
        imports = []
        for entry in pe.DIRECTORY_ENTRY_IMPORT:
            for imp in entry.imports:
                if hasattr(imp, 'name') and imp.name is not None:
                    name = imp.name.decode()
                    imports.append(name)
        cache.set('imports', imports)

    lis = ''
    for imp in imports:
        quoted = urllib.parse.quote(imp)
        malapi_link = f'https://malapi.io/winapi/{quoted}'
        google_link = f'https://google.com/search?q={quoted}'

        cat = cache.get_common(imp)
        if cat is None:
            page = requests.get(malapi_link)
            if not page.ok:
                raise malbook.Error("Can't connect to MalAPI")
            soup = bs4.BeautifulSoup(page.content, 'html.parser')
            found = soup.find_all('span', class_='attack-container')
            if len(found) != 0:
                cat = found[0].text.strip()
            else:
                cat = 'none'
            cache.set_common(imp, cat)

        if cat == 'none':
            lis += f'<li>{_hesc(imp)} [<a href={_hesc(google_link)}>Google</a>]</li>'
        else:
            lis += f'<li>{_hesc(imp)} - <b>{_hesc(cat)}</b> [<a href={_hesc(google_link)}>Google</a>] [<a href={_hesc(malapi_link)}>MalAPI</a>]'

    _head('PE Imports')
    _ul(lis, len(imports))


def _peid(sample, config, cache):
    packer = cache.get('packer')
    if packer is None:
        try:
            packer = peid.identify_packer(sample)[0][1][0]
        except:
            packer = 'Could not detect packer/compiler'

        cache.set('packer', packer)

    _head('Packer/compiler')
    malbook.output(f'<p>{packer}</p>')


def _yara(data, config, cache):
    rules = os.listdir(config.yara_rules)

    if cache.get('yara') is None:
        cache.set('yara', [])

    matches = []
    for r in rules:
        if r in config.yara_ignore:
            continue
        if r in cache.get('yara'):
            matches.append(r)
        else:
            rule_path = path.join(config.yara_rules, r)
            with open(rule_path, 'rt') as f:
                src = f.read()
            rule = yara.compile(source=src)
            rms = rule.match(data=data)
            if len(rms) != 0:
                matches.append(r)

    lis = ''
    for m in matches:
        lis += f'<li>{_hesc(m)}</li>'

    _head('Yara rules that matched sample')
    _ul(lis, len(matches))


def _strings(sample, config, cache):
    strings = cache.get('strings')
    if strings is None:
        floss_exe = config.strings_floss
        out = subprocess.run(
            [floss_exe, '-n', str(config.strings_min_length), '-q', sample],
            capture_output=True,
        )
        if out.returncode != 0:
            raise malbook.Error('FLOSS returned non-zero exit code', out.stderr.decode())
        strings = out.stdout.decode()
        cache.set('strings', strings)

    results = {}
    for s in strings.split('\n'):
        results[s] = []
        for name, rule in config.strings_regex_rules.items():
            if rule.match(s) is not None:
                results[s].append(name)

    # Format output
    lis = ''
    for s, rules in results.items():
        if len(rules) == 0:
            lis += f'<li>{_hesc(s)}</li>'
        else:
            lis += f'<li>{_hesc(s)}<ul>'
            for r in rules:
                lis += f'<li>{_hesc(r)}</li>'
            lis += '</ul></li>'

    _head('Strings')
    _ul(lis, len(results))


def _checksums(data, pe, config, cache):
    md5 = _csum(hashlib.md5, data)
    sha1 = _csum(hashlib.sha1, data)
    sha256 = _csum(hashlib.sha256, data)
    imphash = pe.get_imphash()

    lis = f'<li><b>md5</b> - {md5}</li>'
    lis += f'<li><b>sha1</b> - {sha1}</li>'
    lis += f'<li><b>sha256</b> - {sha256}</li>'
    lis += f'<li><b>Imphash</b> - {imphash}</li>'

    # XXX: Use SHA256 as unique identifier for each malware sample
    cache.set_current_sample(sha256)

    _head('Checksums')
    _ul(lis, 4)


# XXX Helpers


# Computes the checksum and returns the digest. Algorithm
# must be an instance of _hashlib.HASH
def _csum(algorithm, data):
    h = algorithm()
    h.update(data)
    return h.hexdigest()


# XXX: Output helpers


# Escapes HTML sequences in text
def _hesc(text):
    return html.escape(text)


# Outputs a header
def _head(text, lvl=3):
    malbook.output(f'<h{lvl}>{text}</h{lvl}>')


# Outputs an HTML list, hiding contents if there are more than
# hide number of elements
def _ul(lis, n, hide=10):
    if n == 0:
        malbook.output('<p>None</p>')
    elif n <= hide:
        malbook.output(f'<p><ul>{lis}</ul></p>')
    else:
        malbook.output(f'''
        <p>
            <details>
                <summary>
                    Click here to show all <b>{n}</b>
                </summary>
                <ul>
                    {lis}
                </ul>
            </details>
        </p>
        ''')
